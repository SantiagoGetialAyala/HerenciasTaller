package PackageCirculo;


import java.util.Scanner;


class CilindroHueco extends Cilindro {
    private double radioInterno;

    public CilindroHueco() {
        super();
        this.radioInterno = 0;
    }

    @Override
    public void leerDatos() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el radio externo del cilindro hueco: ");
        this.radio = scanner.nextDouble();
        System.out.print("Ingrese el radio interno del cilindro hueco: ");
        this.radioInterno = scanner.nextDouble();
        System.out.print("Ingrese la altura del cilindro hueco: ");
        this.altura = scanner.nextDouble();
    }

    public double area() {
        return 2 * Math.PI * (radio * altura + Math.pow(radio, 2) - Math.pow(radioInterno, 2));
    }

    public double volumen() {
        return Math.PI * altura * (Math.pow(radio, 2) - Math.pow(radioInterno, 2));
    }
}
