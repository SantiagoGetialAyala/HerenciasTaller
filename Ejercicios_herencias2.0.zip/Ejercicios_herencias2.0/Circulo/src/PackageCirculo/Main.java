package PackageCirculo;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Datos del Círculo:");
        Circulo circulo = new Circulo();
        circulo.leerRadio();
        System.out.printf("Área del círculo: %.2f%n", circulo.area());
        System.out.printf("Circunferencia del círculo: %.2f%n", circulo.circunferencia());

        System.out.println("\nDatos del Cilindro:");
        Cilindro cilindro = new Cilindro();
        cilindro.leerDatos();
        System.out.printf("Área del cilindro: %.2f%n", cilindro.area());
        System.out.printf("Volumen del cilindro: %.2f%n", cilindro.volumen());

        System.out.println("\nDatos del Cilindro Hueco:");
        CilindroHueco cilindroHueco = new CilindroHueco();
        cilindroHueco.leerDatos();
        System.out.printf("Área del cilindro hueco: %.2f%n", cilindroHueco.area());
        System.out.printf("Volumen del cilindro hueco: %.2f%n", cilindroHueco.volumen());

        scanner.close();
    }
}
