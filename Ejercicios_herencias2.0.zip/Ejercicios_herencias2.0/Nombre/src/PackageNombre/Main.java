package PackageNombre;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leer los datos del nombre
        System.out.println("Por favor, ingrese los datos personales:");
        System.out.print("Escriba su nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Escriba su primer apellido: ");
        String primerApellido = scanner.nextLine();
        System.out.print("Escriba su segundo apellido: ");
        String segundoApellido = scanner.nextLine();

        // Leer los datos de la dirección
        System.out.println("A continuación, ingrese los datos de su dirección:");
        System.out.print("Indique el nombre de la calle: ");
        String calle = scanner.nextLine();
        System.out.print("Indique la ciudad donde vive: ");
        String ciudad = scanner.nextLine();
        System.out.print("Indique la provincia o estado: ");
        String provincia = scanner.nextLine();
        System.out.print("Indique su código postal: ");
        String codigoPostal = scanner.nextLine();

        // Crear objeto de la clase Direccion
        Direccion direccion = new Direccion(nombre, primerApellido, segundoApellido, calle, ciudad, provincia, codigoPostal);

        // Mostrar los datos
        System.out.println("\nDatos registrados:");
        direccion.mostrar();

        scanner.close();
    }
}
