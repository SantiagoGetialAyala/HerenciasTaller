package PackageNombre;

public class Nombre {
    // Atributos
    private String nombre;
    private String primerApellido;
    private String segundoApellido;

    // Constructor
    public Nombre(String nombre, String primerApellido, String segundoApellido) {
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
    }

    // Método para leer los nombres
    public void leerNombre(String nombre, String primerApellido, String segundoApellido) {
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
    }

    // Método para mostrar el nombre completo
    public void mostrarNombre() {
        System.out.println("Nombre completo: " + nombre + " " + primerApellido + " " + segundoApellido);
    }
}
